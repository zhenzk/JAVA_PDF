package com.alibaba.cloud.examples;

import java.security.PrivateKey;
import org.jose4j.json.JsonUtil;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jwk.RsaJwkGenerator;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.NumericDate;
import org.jose4j.lang.JoseException;
public class GenerateJwtDemo {
    public static void main(String[] args) throws JoseException  {
        RsaJsonWebKey rsaJsonWebKey = RsaJwkGenerator.generateJwk(2048);
        final String publicKeyString = rsaJsonWebKey.toJson(JsonWebKey.OutputControlLevel.PUBLIC_ONLY);
        final String privateKeyString = rsaJsonWebKey.toJson(JsonWebKey.OutputControlLevel.INCLUDE_PRIVATE);
        System.out.println(publicKeyString);
        System.out.println(privateKeyString);


        String keyId = "SHA-256";
          //使用本文2.1节生成的Keypair
//        String privateKeyJson = "{\n" +
//                "    \"p\": \"xaTRCyKkuD1bNWTk0PKbgjg-7hYNCF32il71FpKRvyt0iBBFLo83jRfTpcTws11YSHGDcvQV6XbGPfVBwNJQtKmSqtsLAW5AnzvHFidjvRvuDFk8RaOtJ2KqEfnRO9Qin0Bjxr67VQ33MTi0N4HRS8oqyH4sz9Y2NOgiLSdAqy8\",\n" +
//                "    \"kty\": \"RSA\",\n" +
//                "    \"q\": \"rGG0ZsC4novocSVG2sZjcsXHXlWoidNHjFHC9F3m2m7qwLDNrJ2GT7KRUaJQOC_wBEz82GgxwsHrY5Gfn-s9se-7SJDb9ZGfR0aBcgnbLx4RZpSj72qgHyEFBw15VjDuMWAgyDJ7i6nXtz9EPZ2ooClOzPZa0DCddUXe5mFrdBM\",\n" +
//                "    \"d\": \"BR2IBViv4oPlAd1Xoaw6Brbl07YHFMu4ssbDfSHgDQv6RQ-G673UauvVySHi0NUzGXZoV_OCHQiZ5Ds9_ig0ag1WvjhcYZdu_3lq-tZFB72aauI7CuPq8FsuiVtei14ElLwS93QUOweogtVU3ZNeyUwSq7Q5YSGkpSeiSCOcAbKlau5U4rANX0BPmBvvkZhvldtqYvKlzScY2HrpsdlksUyiq6vsmENla3JI_cLZT_pfNc9TVQBnlwlNssUg7-fOuWPZz8RhSBORHPJctclG8xaEZAEzdxAv7HquZ_wA4gy-O3MjZO5NPySRfUSTCVH6NbfOJT3p3ItXn5CKd31FZQ\",\n" +
//                "    \"e\": \"AQAB\",\n" +
//                "    \"kid\": \"pG8msayLRE-X1oUc68TVmO3CfNmXBncbCN3wdPyvKkA\",\n" +
//                "    \"qi\": \"gm64mOBHV6eMIVKrZ2ACvQJh1Mc37uutvYZBDviP_gKufAZiPL2yWXVfT9JbK-RuttEGENZCUuJMZx9IYF8B-xrr4lmYjs1OnyUFAtDgLM03RuGq9RHzOUhIxP5LEfN67cHbWFml0NNZ5iEXyDxFqQfaG_NhtpgWz3ZngXeICL0\",\n" +
//                "    \"dp\": \"GSIiazYWmE9FH_8ake-oEuEwL3qiYaQBTAtTQ3GUEyllgj__bDJOMCUNhxEKQuTl6yB0RNQBTVULVKmxmOGl3bOKsSt1tNLeaOFjKdAMgOniVbOrVHfB9zY2xl5sWx1Y4cOAbK-ohuJlwt6hHEXn5alp02EoNa3Z6tRyNCe_s4U\",\n" +
//                "    \"dq\": \"lPIbQYmWPBAheNo_vbsbpMj1ujIDXYt8T-c5r5IPbX_XQUXDgTnfGq_tVn8MF3B8UAsBki99h42tSSxDo5dMiJne1hWsqSP5X0mxgYq4o560ZFFc0Prtfdg3Et_2jp3awjkQOks8avIHHSQCX8cBM9pdZ0YaM7c95l3H-oIEqZc\",\n" +
//                "    \"n\": \"hRYrLefwEKT-p4SSpnOfJJQGXN91QqXODMAaaaDLJUzc1zoHCiMt6Q7OzxVwKxd4FurxgPNNmNGmcvRV6nmazhNj2uqeILSM8rqibUZqGayucUdvzXyuA6u9YxPOrw9XK946sVhIRLBhALIFYHf1F5A00t3ckW5yT4BMZqICXmHm2rG8YhaCuFyinnLHA0lD4pXSTR9xCp0cPKK3_KzkRKG-4G93SzqhBH7TBnzjTW2dwoThzXdlbouyZ4-9u7N1DM_Z-cs5tq_zkcduFtJBh3xL2wh_4XLgWD-zxfyBw8hiE2UJtydyzVWhAfzBvU4sjidaahFxUxF4rXZBkwMAfQ\"\n" +
//                "}";
        JwtClaims claims = new JwtClaims();
        claims.setGeneratedJwtId();
        claims.setIssuedAtToNow();
        //过期时间一定要设置
//        NumericDate date = NumericDate.now();
//        date.addSeconds(120*60000);
//        claims.setExpirationTime(date);
//        claims.setNotBeforeMinutesInThePast(1);
//        claims.setSubject("YOUR_SUBJECT");
//        claims.setAudience("YOUR_AUDIENCE");
//        //添加自定义参数，所有值请都使用String类型
//        claims.setClaim("userId", "1213234");
//        claims.setClaim("email", "userEmail@youapp.com");
        JsonWebSignature jws = new JsonWebSignature();
        jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);
        jws.setKeyIdHeaderValue(keyId);
        jws.setPayload(claims.toJson());
        PrivateKey privateKey = new RsaJsonWebKey(JsonUtil.parseJson(privateKeyString)).getPrivateKey();
     
        jws.setKey(privateKey);
        String jwtResult = jws.getCompactSerialization();
        System.out.println(jwtResult);




    }
}
package com.tuling.learnjuc.container.map;

public class User {

    @Override
    public int hashCode() {
        return 1;
    }
}

package cn.tulingxueyuan.safe;

/**
 * @author Mark老师   图灵学院 https://www.tulingxueyuan.cn/
 * 类说明：无状态的类
 */
public class Stateless {

    final int i = 1;

    public int getI() {
        return i;
    }


//    public void add(int x, int y ){
//        i++;
//    }

}
